package week3.day1;

public class College {
	
	public void collegeName()
	{
		
		
		System.out.println("VIT");
		
	}
     public void collegeCode()
     {
    	 
    	 System.out.println("V003");
     }
	
	public void collegeRank()
	{
		
		System.out.println("3");
		
	}
     
     
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
