package week3.day1;

public class Computer {

	public void computerMode()
	{
		System.out.println("computer mode");
	}
	
	
	public static void main(String[] args) {
		
		
		

	}

}
