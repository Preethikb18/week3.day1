package week3.day1;

public class Department {
	
	public void deptName()
	{
		System.out.println("Computer science engineering");
	}

	public static void main(String[] args) {


	}

}
