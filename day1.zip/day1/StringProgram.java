package week3.day1;

public class StringProgram {

	public static void main(String[] args) {
		
		
		String str1 ="Welcome";
		String str2 = "Welcome";
		// TODO Auto-generated method stub
		char[] charArray = str1.toCharArray();
		System.out.println(charArray);
		 for (int i =0 ; i < charArray.length; i++) {
		//System.out.println(charArray);
		 }
		     int[] num=new int [4];
			 char[]ch =new char[4];
			 ch[0]='W';
			 ch[1]='E';
			 
			// get the index of specific character
			  int indexOf = str1.indexOf('c');
			 System.out.println(indexOf);
			//How to get part of string//welcome
			 //to give  the Start index
			 String substring = str1.substring(indexOf);
			 System.out.println(substring);
			//start and stop index+1
			 //System.out.println(str1.substring(3,6));
			 String name="       TestLeafLocatedInChennaiIntheYear2009"      ;
			//to remove the space
			 //System.out.println(name);
			 String trim = name.trim();
			 //System.out.println(trim);
			 //Split the String
			 String[] split = name.split("");
			 //System.out.println(split[1]);
			 for (int i = 0; i < split.length; i++) {
				 
				//System.out.println(split[i]);
			}
			 
			//convert the TO UPPERE CASE
			 System.out.println(str1.toUpperCase());
			 
			 //convert the String to lowercase
			 System.out.println(str1.toLowerCase());
			 
			 //How to replace String
			 String name1="       TestLeafLocatedInChennaiIntheYear2009"      ;
			 
			 String replace = name1.replace("e", "@");
			 System.out.println(replace);
			 String replaceAll = name1.replaceAll("\\D", " ");
			 System.out.println(replaceAll);
			 


	}

}
